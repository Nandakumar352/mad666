package com.example.smspgm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText txtmobile;
    EditText txtMessage;
    Button btnsms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtmobile = findViewById(R.id.phonenumber);
        txtMessage = findViewById(R.id.smsbody);
        btnsms = findViewById(R.id.smsIntent);


        btnsms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    SmsManager smgr =SmsManager.getDefault();
                    smgr.sendTextMessage(txtmobile.getText().toString(),null,txtMessage.getText().toString(),null,null);
                    Toast.makeText(MainActivity.this, "SMS sent successfully", Toast.LENGTH_SHORT).show();

                }
                catch (Exception e){
                    Toast.makeText(MainActivity.this, "Sms Failed to send please try again", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}